package com.lavanderia.dao;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseConnection {
    private static DataSource dataSource;
    
    static {
        try {
            System.out.println("[DatabaseConnection] Inicializando DataSource...");
            Context initContext = new InitialContext();
            Context envContext = (Context) initContext.lookup("java:/comp/env");
            dataSource = (DataSource) envContext.lookup("jdbc/lavanderiaDB");
            System.out.println("[DatabaseConnection] DataSource inicializado correctamente");
        } catch (NamingException e) {
            System.err.println("[DatabaseConnection] ERROR al inicializar DataSource: " + e.getMessage());
            throw new RuntimeException("Error al inicializar DataSource", e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        System.out.println("[DatabaseConnection] Intentando obtener conexión...");
        Connection conn = dataSource.getConnection();
        
        // Verificación adicional de la conexión
        if (conn != null && !conn.isClosed()) {
            System.out.println("[DatabaseConnection] Conexión establecida exitosamente");
            System.out.println("[DatabaseConnection] URL: " + conn.getMetaData().getURL());
            System.out.println("[DatabaseConnection] Usuario: " + conn.getMetaData().getUserName());
        } else {
            System.err.println("[DatabaseConnection] ERROR: No se pudo establecer conexión");
        }
        
        return conn;
    }
}