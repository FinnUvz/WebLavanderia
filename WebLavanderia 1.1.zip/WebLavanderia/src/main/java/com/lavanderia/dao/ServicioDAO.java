package com.lavanderia.dao;

import com.lavanderia.dto.ServicioDTO;
import com.lavanderia.dao.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServicioDAO {
    private static final Logger LOG = Logger.getLogger(ServicioDAO.class.getName());

    public List<ServicioDTO> findAll() {
        List<ServicioDTO> servicios = new ArrayList<>();
        String sql = "SELECT id, nombre, descripcion, precio FROM servicios";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                ServicioDTO servicio = new ServicioDTO(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio")
                );
                servicios.add(servicio);
            }
        } catch (SQLException e) {
            LOG.log(Level.SEVERE, "Error al obtener servicios", e);
        }
        return servicios;
    }
}