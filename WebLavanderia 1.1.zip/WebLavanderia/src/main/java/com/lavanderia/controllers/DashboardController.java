package com.lavanderia.controllers;

import com.lavanderia.dao.ServicioDAO;
import com.lavanderia.dto.ServicioDTO;
import com.lavanderia.handlers.ServicioHandlerChain;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "DashboardController", urlPatterns = {"/dashboard"})
public class DashboardController extends HttpServlet {

    private final ServicioDAO servicioDao = new ServicioDAO();
    private final ServicioHandlerChain handlerChain = new ServicioHandlerChain();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener datos
        List<ServicioDTO> servicios = servicioDao.findAll();
        
        // Procesar con Chain of Responsibility
        handlerChain.process(servicios, request);
        
        // Enviar a la vista
        request.setAttribute("servicios", servicios);
        request.setAttribute("pageTitle", "Dashboard de Lavandería");
        request.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(request, response);
    }
}