package com.lavanderia.handlers;

import com.lavanderia.dto.ServicioDTO;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public class CategoriaHandler implements Handler {
    private Handler next;

    public CategoriaHandler(Handler next) {
        this.next = next;
    }

    @Override
    public void handle(List<ServicioDTO> servicios, HttpServletRequest request) {
        servicios.forEach(servicio -> {
            if (servicio.getNombre().contains("Lavado")) {
                servicio.setCategoria("Lavado");
            } else if (servicio.getNombre().contains("Planchado")) {
                servicio.setCategoria("Planchado");
            } else {
                servicio.setCategoria("Otros");
            }
        });

        if (next != null) {
            next.handle(servicios, request);
        }
    }
}