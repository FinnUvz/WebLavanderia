package com.lavanderia.handlers;

import com.lavanderia.dto.ServicioDTO;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

public class PrecioHandler implements Handler {
    @Override
    public void handle(List<ServicioDTO> servicios, HttpServletRequest request) {
        double total = servicios.stream()
            .mapToDouble(ServicioDTO::getPrecio)
            .sum();
        request.setAttribute("totalServicios", total);
    }
}