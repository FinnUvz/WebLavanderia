package com.lavanderia.handlers;

import com.lavanderia.dto.ServicioDTO;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

public class ServicioHandlerChain {
    private Handler chain;

    public ServicioHandlerChain() {
        buildChain();
    }

    private void buildChain() {
        this.chain = new CategoriaHandler(new PrecioHandler());
    }

    public void process(List<ServicioDTO> servicios, HttpServletRequest request) {
        chain.handle(servicios, request);
    }
}