package com.lavanderia.dto;

public class Servicio {
    private int id;
    private String nombre;
    private String descripcion;
    private double precio;
    private String categoria; // Nuevo campo para el handler

    // Constructor, getters y setters
    public Servicio() {}

    // Constructor con parámetros
    public Servicio(int id, String nombre, String descripcion, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    // Getters y Setters (usados por EL en JSP)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    // ... (implementar todos los getters/setters)
}