package com.lavanderia.servlets;

import com.lavanderia.dao.DatabaseConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // ⬇️ Prueba de conexión a la base de datos
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                System.out.println("[DashboardServlet] Conexión obtenida exitosamente en el servlet.");
            } else {
                System.err.println("[DashboardServlet] La conexión es nula.");
            }
        } catch (SQLException e) {
            System.err.println("[DashboardServlet] Error al conectar con la base de datos: " + e.getMessage());
        }

        request.setAttribute("pageTitle", "Dashboard de Lavandería");
        request.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(request, response);
    }
}