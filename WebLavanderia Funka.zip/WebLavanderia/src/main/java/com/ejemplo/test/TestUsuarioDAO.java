/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.test;

import com.ejemplo.dao.UsuarioDAO;
import com.ejemplo.dto.UsuarioDTO;

public class TestUsuarioDAO {
    public static void main(String[] args) {
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        
        // Test listar usuarios
        System.out.println("Listado de usuarios:");
        usuarioDAO.listarUsuarios().forEach(System.out::println);
        
        // Test insertar usuario
        UsuarioDTO nuevoUsuario = new UsuarioDTO();
        nuevoUsuario.setNombre("Juan Pérez");
        nuevoUsuario.setCorreo("juan@example.com");
        nuevoUsuario.setTelefono("5551234567");
        nuevoUsuario.setContrasena("secreto123");
        nuevoUsuario.setDireccion("Calle Falsa 123");
        
        try {
            usuarioDAO.insertarUsuario(nuevoUsuario);
            System.out.println("Usuario insertado correctamente");
        } catch (Exception e) {
            System.err.println("Error al insertar usuario: " + e.getMessage());
        }
    }
}