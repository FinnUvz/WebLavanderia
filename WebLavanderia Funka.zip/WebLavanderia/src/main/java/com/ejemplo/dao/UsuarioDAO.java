/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ejemplo.dao;

import com.ejemplo.dto.UsuarioDTO;
import com.ejemplo.dao.MySQLConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    
    public List<UsuarioDTO> listarUsuarios() {
        List<UsuarioDTO> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        
        try (Connection conn = MySQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                UsuarioDTO usuario = new UsuarioDTO();
                usuario.setIdUsuario(rs.getLong("id_usuario"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setCorreo(rs.getString("correo"));
                usuario.setTelefono(rs.getString("telefono"));
                usuario.setDireccion(rs.getString("direccion"));
                usuarios.add(usuario);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }
    
    public void insertarUsuario(UsuarioDTO usuario) throws SQLException, ClassNotFoundException {
    String sql = "INSERT INTO usuarios (nombre, correo, telefono, contrasena, direccion) VALUES (?, ?, ?, ?, ?)";
    
    try (Connection conn = MySQLConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
        
        pstmt.setString(1, usuario.getNombre());
        pstmt.setString(2, usuario.getCorreo());
        pstmt.setString(3, usuario.getTelefono());
        pstmt.setString(4, usuario.getContrasena());
        pstmt.setString(5, usuario.getDireccion());
        
        int affectedRows = pstmt.executeUpdate();
        
        if (affectedRows == 0) {
            throw new SQLException("No se pudo insertar el usuario, ninguna fila afectada");
        }
        
        try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                usuario.setIdUsuario(generatedKeys.getLong(1));
            } else {
                throw new SQLException("No se pudo obtener el ID generado");
            }
        }
    } catch (SQLException e) {
        // Loguear el error real para diagnóstico
        System.err.println("Error SQL al insertar usuario: " + e.getMessage());
        throw e; // Relanzamos la excepción
    }
    }
}