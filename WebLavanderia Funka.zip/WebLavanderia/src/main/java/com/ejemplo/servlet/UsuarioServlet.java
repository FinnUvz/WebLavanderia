package com.ejemplo.servlet;

import com.ejemplo.dao.UsuarioDAO;
import com.ejemplo.dto.UsuarioDTO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "UsuarioServlet", urlPatterns = {"/usuarios"})
public class UsuarioServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        String mensaje = "";
        String tipoMensaje = "success"; // success, danger, warning, info
        
        try {
            if ("listar".equals(action) || action == null) {
                List<UsuarioDTO> usuarios = usuarioDAO.listarUsuarios();
                request.setAttribute("usuarios", usuarios);
                request.getRequestDispatcher("/usuarios/listar.jsp").forward(request, response);
            } else if ("nuevo".equals(action)) {
                request.getRequestDispatcher("/usuarios/formulario.jsp").forward(request, response);
            } else if ("guardar".equals(action)) {
                UsuarioDTO usuario = new UsuarioDTO();
                usuario.setNombre(request.getParameter("nombre"));
                usuario.setCorreo(request.getParameter("correo"));
                usuario.setTelefono(request.getParameter("telefono"));
                usuario.setContrasena(request.getParameter("contrasena"));
                usuario.setDireccion(request.getParameter("direccion"));
                
                // Validación básica
                if(usuario.getNombre() == null || usuario.getNombre().isEmpty() ||
                   usuario.getCorreo() == null || usuario.getCorreo().isEmpty() ||
                   usuario.getContrasena() == null || usuario.getContrasena().isEmpty()) {
                    throw new Exception("Nombre, correo y contraseña son campos obligatorios");
                }
                
                usuarioDAO.insertarUsuario(usuario);
                mensaje = "Usuario registrado correctamente";
                request.setAttribute("mensaje", mensaje);
                request.setAttribute("tipoMensaje", tipoMensaje);
                response.sendRedirect(request.getContextPath() + "/usuarios?action=listar");
            }
        } catch (Exception e) {
            e.printStackTrace();
            mensaje = "Error al registrar usuario: " + e.getMessage();
            tipoMensaje = "danger";
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("tipoMensaje", tipoMensaje);
            
            if("guardar".equals(action)) {
                // Volvemos al formulario con los datos ingresados
                request.setAttribute("usuario", new UsuarioDTO(
                    request.getParameter("nombre"),
                    request.getParameter("correo"),
                    request.getParameter("telefono"),
                    request.getParameter("contrasena"),
                    request.getParameter("direccion")
                ));
                request.getRequestDispatcher("/usuarios/formulario.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/usuarios?action=listar");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}